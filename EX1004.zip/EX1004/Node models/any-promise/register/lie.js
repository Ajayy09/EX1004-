'use strict';
require('../register')('lie', {Promise: require('lie')})
